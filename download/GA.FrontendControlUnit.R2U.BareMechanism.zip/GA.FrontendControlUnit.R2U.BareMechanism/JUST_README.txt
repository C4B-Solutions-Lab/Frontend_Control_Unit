Setting up && running !

 - provide all required libraries for [.fcu] and [user-defined]
 - provide valid configuration files


Paths definition:
 - all paths should be relative to View/Index.html, i.e. to View/




==================================
 How it really works ?
==================================
  Go to OneDrive directory under this address [ https://1drv.ms/f/s!Av2ZrNqOVnWL9yW0tKXfC3v-oCxz ] for all on Frontend Control Unit !